<?php 
include('config.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>爱客影视管理后台 - Powered by www.woaik.com</title>
<meta name="keywords" content="爱客源码" />
<meta name="description" content="爱客影视，http://woaik.com/" />
<link href="./images/woaik.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" type="image/x-icon" href="./../favicon.ico">
</head>
<body>
<?php $nav = 'home';include('head.php'); ?>
<div id="hd_main">
   <div style="margin:20px;">

      <table width="600" border="0" class="tablecss" cellspacing="0" cellpadding="0" align="center">
   <tr>
    <td colspan="2" align="center">欢迎使用爱客影院管理系统！</td>
    </tr>
  <tr>
    <td align="right">当前使用版：</td>
    <td><span>V3.3</span></td>
  </tr>
  <tr>
    <td align="right">最新版：</td>
    <td><a href="https://jq.qq.com/?_wv=1027&k=4B2cno8" target="_blank"><font color="#FF0000">点击查看</font></a></td>
  </tr>
  <tr>
    <td width="213" align="right">服务器操作系统：</td>
    <td width="387"><?php $os = explode(" ", php_uname()); echo $os[0];?> (<?php if('/'==DIRECTORY_SEPARATOR){echo $os[2];}else{echo $os[1];} ?>)</td>
  </tr>
  <tr>
    <td width="213" align="right">服务器解译引擎：</td>
    <td width="387"><?php echo $_SERVER['SERVER_SOFTWARE'];?></td>
  </tr>
  <tr>
    <td width="213" align="right">PHP版本：</td>
    <td width="387"><?php echo PHP_VERSION?></td>
  </tr>
  <tr>
    <td align="right">域名：</td>
    <td><?php echo $_SERVER['HTTP_HOST']?></td>
  </tr>
  <tr>
    <td align="right">allow_url_fopen：</td>
    <td><?php echo ini_get('allow_url_fopen') ? '<span class="green">支持</span>' : '<span class="red">不支持</span>'?></td>
  </tr>
  <tr>
    <td align="right">curl_init：</td>
    <td><?php if ( function_exists('curl_init') ){ echo '<span class="green">支持</span>' ;}else{ echo '<span class="red">不支持</span>';}?></td>
  </tr>

<tr>
    <td align="right">/data/目录权限检测：</td>
    <td><?php echo is_writable('../data/') ? '<span class="green">可写</span>' : '<span class="red">不可写</span>'?></td>
  </tr>  

  <tr>
    <td colspan="2" style="line-height:220%; text-indent:28px;">欢迎使用本程序，源码交<a href="https://jq.qq.com/?_wv=1027&k=4B2cno8" target="_blank">（QQ群：109199812）</a>，感谢朋友们的支持！</br><font color="red">温馨提示：爱客影院源码分【授权版】跟【免费版】，授权版演示地址：<a href="http://v.woaik.com" target="_blank">http://v.woaik.com</a></font></br>授权版为98元/永久。</br><font color="red">除我本人外，把前面这段删除或修改的都是傻逼！</font></br>
3.3版本更新：</br>
1.去除“电影”分类下的“伦理”分类，可以用百度CDN啦！ </br>
2.修复“搜索”部分环境下失效的问题。 </br>
3.增加视频资源，基本所有的视频资源都能搜到。 </br>
4.增加百度网盘搜索及磁力搜索。 </br>
5.增加电影播放界面播放源选择。 </br>
6.增加电视剧播放显示正在播放集数。</br>
7.增加后台发布视频功能，尝鲜视频不错过！</br>
8.修复授权系统问题，换成授权码，可自助授权并且百分百不掉。</br>
</td>
    </tr>
   
</table>

   </div>

</div>
<?php include('foot.php'); ?>
</body>
</html>
