<?php
 $aik =  array (
  'sitename' => '爱客影院',
  'pcdomain' => 'http://v.woaik.com',
  'title' => '﻿爱客影院-免VIP抢先观看最新好看的电影和电视剧',
  'keywords' => '爱客影院,电视直播网站,零八影院快播,高清云影视,云点播,免费看视频,湖南卫视直播,80电影网,最新电影天堂免费在线观看',
  'description' => '﻿爱客影院,热剧快播,最好看的剧情片尽在﻿爱客影院,高清云影视免费为大家提供最新最全的免费电影，电视剧，综艺，动漫无广告在线云点播，以及电视直播',
  'homelink' => '<a href="http://woaik.w3.luyouxia.net/play.php?play=aHR0cDovL3d3dy4zNjBrYW4uY29tL20vZ3Ficlp4SDRRWHIwVGguaHRtbA==" target="_blank"><font color="red">【爱客影视】</font></a>',
  'icp' => '国ICP备18888888号',
  'foot' => '本站提供的最新电影和电视剧资源均系收集于各大视频网站,本站只提供web页面服务,并不提供影片资源存储,也不参与录制、上传</br>若本站收录的节目无意侵犯了贵司版权，请给网页底部邮箱地址来信,我们会及时处理和回复,谢谢。',
  'tongji' => '<script src="https://s13.cnzz.com/z_stat.php?id=1262571414&web_id=1262571414" language="JavaScript"></script>',
  'changyan' => '<!--PC和WAP自适应版-->
<div id="SOHUCS" ></div> 
<script type="text/javascript"> 
(function(){ 
var appid = \'cysHhpVdt\'; 
var conf = \'prod_e662d414f251fcb3dd4bce950024c923\'; 
var width = window.innerWidth || document.documentElement.clientWidth; 
if (width < 960) { 
window.document.write(\'<script id="changyan_mobile_js" charset="utf-8" type="text/javascript" src="https://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=\' + appid + \'&conf=\' + conf + \'"><\\/script>\'); } else { var loadJs=function(d,a){var c=document.getElementsByTagName("head")[0]||document.head||document.documentElement;var b=document.createElement("script");b.setAttribute("type","text/javascript");b.setAttribute("charset","UTF-8");b.setAttribute("src",d);if(typeof a==="function"){if(window.attachEvent){b.onreadystatechange=function(){var e=b.readyState;if(e==="loaded"||e==="complete"){b.onreadystatechange=null;a()}}}else{b.onload=a}}c.appendChild(b)};loadJs("https://changyan.sohu.com/upload/changyan.js",function(){window.changyan.api.config({appid:appid,conf:conf})}); } })(); </script>',
  'youlian' => '<a target="blank" class="gobtn" href="http://www.woaik.com">爱客资源网</a>	
<a target="blank" class="gobtn" href="https://jq.qq.com/?_wv=1027&amp;k=4B2cno8">加入Q群</a>',
  'shouquan' => '',
  'jiekou1' => 'https://api.47ks.com/webcloud/?v=',
  'jiekou2' => 'http://api.baiyug.cn/vip/index.php?url=',
  'jiekou3' => 'http://jiexi.92fz.cn/player/vip.php?url=',
  'jiekou4' => 'http://api.nepian.com/ckparse/?url=',
  'jiekou5' => 'http://aikan-tv.com/?url=',
  'jiekou6' => 'http://j.zz22x.com/jx/?url=',
  'jiekou7' => 'http://www.efunfilm.com/yunparse/index.php?url=',
  'jiekou8' => 'https://api.flvsp.com/?url=',
  'jiekou9' => 'http://api.xfsub.com/index.php?url=',
  'jiekou10' => 'http://api.47ks.com/webcloud/?v=',
  'admin_name' => 'admin',
  'admin_pass' => '3ceb0e9fb16f8673c35f707e8657124a',
  'admin_email' => 'admin@admin.com',
  'logo_dh' => '<img src="images/logo.png">',
  'logo_ss' => '<img id="imgsrc" src="images/sologo.png">',
  'movie_ad' => '<a href="http://vip.woaik.com" target="_blank"><img src="images/dc5c7986daef50c.gif" style="width:100%"></a>',
  'tv_ad' => '<a href="http://vip.woaik.com" target="_blank"><img src="images/dc5c7986daef50c.gif" style="width:100%"></a>',
  'zongyi_ad' => '<a href="http://vip.woaik.com" target="_blank"><img src="images/dc5c7986daef50c.gif" style="width:100%"></a>',
  'dongman_ad' => '<a href="http://vip.woaik.com" target="_blank"><img src="images/dc5c7986daef50c.gif" style="width:100%"></a>',
  'bofang_ad' => '<a href="http://vip.woaik.com" target="_blank"><img src="images/gg.png" style="width:100%"></a>',
  'jiazai_ad' => '<a href="http://vip.woaik.com" target="_blank"><img src="images/jiazai.png" width="100%"></a>',
  'tishi_ad' => '<p style="text-align:center;color: #fff;font-size: 10px;background: #6ED56C;padding:11px 8px;border-radius: 2px;">扫描右上角二维码，关注“爱客影院”官方微信，看电影更方便!</p>',
  'dbts' => '【点击选择剧集才会播放哦！】',
  'zfb_ad' => '<img src="images/zfb.png">',
  'wx_ad' => '<img src="images/wx.png">',
  'cebian1_ad' => '<a class="style02" href="" target="_blank"><strong>关注微信</strong><div class="article-wechats"> </br> <img src="images/qrcode.png"></div> </a>',
  'cebian2_ad' => '<a class="style02" href="http://vip.woaik.com" target="_blank"><strong>优惠券</strong><h2>爱客券券-优惠购物</h2><p>淘宝天猫内部优惠券,公开优惠券搜索，省钱购买！
领取内部优惠券，一样的东西，领券购买一般比自己直接买【省30%-60%】不等，券额多大就是省多少钱！</p></a>',
  'cebian3_ad' => '<h3>广告赞助</h3>			
<div class="textwidget"><a href="http://www.58renqifu.com/userreg/register/6605/a7459479d2f7053b79d20888f0552f1f" target="_blank"><img src="images/jianzhi.png" width="100%"></a>',
  'cebian4_ad' => '<a class="style01" href="http://wpa.qq.com/msgrd?v=3&uin=776774592&site=qq&menu=yes" target="_blank"><strong>源码出售</strong><h2>更好的视频主题</h2><p>1.扁平化、简洁风、多功能配置，优秀的电脑、平板、手机支持，响应式布局，不同设备不同展示效果...2.视频全自动采集，不需人工干预，懒人必备！</p></a></div>',
  'top1_ad' => '<a href="http://v.woaik.com/mplay.php?mso=19285"><font color="#FF0000">战狼Ⅱ</font></a>',
  'top2_ad' => '<a href="app.html">客户端</a>',
  'top_ad' => '<a href="http://vip.woaik.com">优惠券</a>',
  'weixin_ad' => '<img src="images/qrcode.png">',
  'end_ad' => '<a href="http://vip.xiaoerhu.com"><span><img src="images/gouwu.png"/>购物</span></a>',
  'hometopnotice' => '',
  'hometopright' => '',
  'sort' => '1,2,3,4,5,6,7,8,9,10',
  'joinhotkey' => '0',
);
?>