DROP TABLE IF EXISTS `pay_order`;
CREATE TABLE `pay_order` (
`trade_no` varchar(64) NOT NULL,
`out_trade_no` varchar(64) NOT NULL,
`notify_url` varchar(64) DEFAULT NULL,
`return_url` varchar(64) DEFAULT NULL,
`type` varchar(20) NOT NULL,
`buyer` varchar(30) DEFAULT NULL,
`pid` int(11) NOT NULL,
`addtime` datetime DEFAULT NULL,
`endtime` datetime DEFAULT NULL,
`name` varchar(64) NOT NULL,
`money` varchar(32) NOT NULL,
`status` int(1) NOT NULL DEFAULT '0',
 PRIMARY KEY (`trade_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `pay_user`;
CREATE TABLE `pay_user` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`uid` int(11) DEFAULT NULL,
`key` varchar(32) NOT NULL,
`note` varchar(10) DEFAULT NULL,
`qq` varchar(150) DEFAULT NULL,
`account` varchar(32) DEFAULT NULL,
`username` varchar(10) DEFAULT NULL,
`alipay_uid` varchar(32) DEFAULT NULL,
`money` decimal(10,2) NOT NULL,
`url` varchar(64) DEFAULT NULL,
`addtime` datetime DEFAULT NULL,
`apply` int(1) NOT NULL DEFAULT '0',
`level` int(1) NOT NULL DEFAULT '1',
`type` int(1) NOT NULL DEFAULT '0',
`active` int(1) NOT NULL DEFAULT '0',
 PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1000;

DROP TABLE IF EXISTS `pay_settle`;
CREATE TABLE `pay_settle` (
`id` int(11) NOT NULL auto_increment,
`pid` int(11) NOT NULL,
`batch` varchar(20) NOT NULL,
`type` varchar(10) NOT NULL,
`username` varchar(10) NOT NULL,
`account` varchar(32) NOT NULL,
`money` decimal(10,2) NOT NULL,
`fee` decimal(10,2) NOT NULL,
`time` datetime DEFAULT NULL,
`status` int(1) NOT NULL DEFAULT '0',
 PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `panel_user`;
CREATE TABLE `panel_user` (
`id` int(11) NOT NULL auto_increment,
`token` varchar(32) NOT NULL,
`user` varchar(32) NOT NULL,
`pwd` varchar(32) NOT NULL,
`email` varchar(32) DEFAULT NULL,
`phone` varchar(20) DEFAULT NULL,
`name` varchar(10) DEFAULT NULL,
`regtime` datetime DEFAULT NULL,
`logtime` datetime DEFAULT NULL,
`level` int(1) NOT NULL DEFAULT '1',
`type` int(1) NOT NULL DEFAULT '0',
`active` int(1) NOT NULL DEFAULT '0',
 PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `panel_log`;
CREATE TABLE `panel_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `type` varchar(20) NULL,
  `date` datetime NOT NULL,
  `city` varchar(20) DEFAULT NULL,
  `data` text NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;