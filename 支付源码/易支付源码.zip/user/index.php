﻿<?php
include("../includes/common.php");
if (!$islogin2)
{
    exit('<script>alert("请先登录!");window.location.href="./login.php";</script>');
}
$title='用户中心';
include './head.php';
?>
<?php
$orders=$DB->query("SELECT * from pay_order WHERE pid={$pid}")->rowCount();
$today=date("Y-m-d").' 00:00:00';
$lastday=date("Y-m-d",strtotime("-1 day")).' 00:00:00';
$numrows=$DB->query("SELECT * from pay_settle WHERE pid={$pid}")->rowCount();
$pagesize=20;
$pages=intval($numrows/$pagesize);
$rs=$DB->query("SELECT * from pay_order where pid={$pid} and status=1 and endtime>='$today'");
$order_today=0;
while($row = $rs->fetch())
{
	$order_today+=$row['money'];
}

$rs=$DB->query("SELECT * from pay_order where pid={$pid} and status=1 and endtime>='$lastday' and endtime<'$today'");
$order_lastday=0;
while($row = $rs->fetch())
{
	$order_lastday+=$row['money'];
}

$rs=$DB->query("SELECT * from pay_settle where pid={$pid} and status=1");
$settle_money=0;
$max_settle=0;
$chart='';
$i=0;
while($row = $rs->fetch())
{
	$settle_money+=$row['money'];
	if($row['money']>$max_settle)$max_settle=$row['money'];
	if($i<9)$chart.='['.$i.','.$row['money'].'],';
	$i++;
}
$chart=substr($chart,0,-1);

?>
 <div id="content" class="app-content" role="main">
    <div class="app-content-body ">

<div class="bg-light lter b-b wrapper-md hidden-print">
  <h1 class="m-n font-thin h3">用户中心</h1>
  <small class="text-muted">欢迎使用<?php echo $conf['web_name']?></small>
</div>
                    <div class="wrapper">
                        <div class="col-lg-4 col-md-6">
                            <div class="panel b-a">
                                <div class="panel-heading bg-info dk no-border wrapper-lg"></div>
                                <div class="text-center m-b clearfix">
                                    <div class="thumb-lg avatar m-t-n-xl">
                                        <img alt="image" class="b b-3x b-white" src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $userrow['qq']?>&spec=100">
                                    </div>
                                    <div class="h4 font-thin m-t-sm"><?php echo $pid?></div>
                                    <span class="text-muted text-xs block">商户ID:<?php echo $pid?></span>
                                </div>
                                <li class="list-group-item">
                                    <span class="badge bg-info"><?php echo $userrow['money']?>￥</span>
                                    <i class="fa fa-jpy fa-fw text-muted"></i> 
                                    账号余额
                                  </a>
                                  <li class="list-group-item">
                                    <span class="badge bg-info"><?php echo $userrow['key']?></span>
                                    <i class="fa fa-asterisk fa-fw text-muted"></i> 商户密钥</li>
                                  <li class="list-group-item">
                                  <?php if(empty($userrow['alipay_uid'])){?>
                                  <span class="badge bg-info"><a href="oauth.php?bind=true" class="badge btn-danger btn-xs" target="_blank">绑定支付宝账号</a></span>
                                  <i class="fa fa-asterisk fa-fw text-muted"></i> 账号绑定</li>
                                  <?php }else{?>
                                  已绑定支付宝UID:<?php echo $userrow['alipay_uid']?>&nbsp;<span class="badge bg-info"><a href="oauth.php?unbind=true" class="badge btn-danger btn-xs" onclick="return confirm('解绑后将无法通过支付宝一键登录，是否确定解绑？');">解绑账号</a></span>
                                  <?php }?>
                                  </li>
                                </ul>
                                    
                                <div class="btn-group btn-group-justified">
                                    <a href="//jq.qq.com/?_wv=1027&k=5Leqkwe" class="btn btn-primary">官方Q群</a>
                                    <a href="./apply.php" class="btn btn-info" data-pjax>申请结算</a>
                                    <a href="./order.php" class="btn btn-success" data-pjax>订单明细</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="panel panel-info">
                                <div class="panel-heading font-bold">最新公告</div>
                                <div class="panel-body">
							<center><iframe width="280" scrolling="no" height="25" frameborder="0" allowtransparency="true" src="http://i.tianqi.com/index.php?c=code&id=34&icon=1&num=3"></iframe></center>
<div class="list-group-item reed"><marquee scrollamount="8" direction="left" align="Middle" style="font-weight: bold;line-height: 20px;font-size: 20px;color: #FF0000;"><img border="0" width="32" src="http://www.hx-mz.cn/images/new.gif">您遇到问题可以联系我们的官方结算QQ群：636277433 感谢您的使用。</marquee></div>
                                <a class="list-group-item"><span class="pull-right"> </span><em class="fa fa-fw fa-volume-up mr"></em><?php echo $conf['web_name']?>-官方网站<?php echo $conf['local_domain']?></a>
								<a class="list-group-item"><span class="pull-right"> </span><em class="fa fa-fw fa-volume-up mr"></em>提现时间：每日0点左右为统一结算记账时间，正常情况到账时间为当天下午的1点到2点之内，具体时间以官方通知为准。如遇节假日顺延；</a>
								<a class="list-group-item"><span class="pull-right"> </span><em class="fa fa-fw fa-volume-up mr"></em>官方结算群：636277433---客服QQ：<?php echo $conf['web_qq']?>------有问题请联系我们。</a>
								   </div>                         
								</div>
                            </div>
                        <div class="col-lg-4 col-md-12">
                            <div class="panel panel-info">
                                <div class="panel-heading font-bold">用户数据统计</div>
                                <div class="panel-body text-center">
                                    <div class="col-sm-6">
                                        <div class="block panel padder-v bg-primary item">
                                            <span class="text-white font-thin h1 block"><?php echo $orders?>个</span>
                                            <span class="text-muted text-xs">订单总数</span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="block panel padder-v bg-info item">
                                            <span class="text-white font-thin h1 block">￥<?php echo $settle_money?></span>
                                            <span class="text-muted text-xs">已结算余额</span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="block panel padder-v bg-success item">
                                            <span class="text-white font-thin h1 block">￥<?php echo $order_today?></span>
                                            <span class="text-muted text-xs">今日收入</span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="block panel padder-v bg-dark item">
                                            <span class="text-white font-thin h1 block">￥<?php echo $order_lastday?></span>
                                            <span class="text-muted text-xs">昨日收入</span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="block panel padder-v bg-info item">
                                            <span class="text-white font-thin h1 block">￥<?php echo $userrow['money']?></span>
                                            <span class="text-muted text-xs">账号余额</span>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="block panel padder-v bg-primary item">
                                            <span class="text-white font-thin h1 block">￥<?php echo $order_today?></span>
                                            <span class="text-muted text-xs">今日收入</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
             <div class="row">
                <div class="col-md-12">
                            <div class="panel panel-info">
                                <div class="panel-heading font-bold">结算记录&nbsp;(<?php echo $numrows?>)</div>
                                <div class="panel-body text-center">
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
          <thead><tr><th>ID</th><th>收款方式</th><th>结算账号</th><th>结算金额</th><th>手续费</th><th>结算时间</th><th>状态</th></tr></thead><tbody>
<?php
$numrows=$DB->query("SELECT * from pay_settle WHERE pid={$pid}")->rowCount();
$pagesize=20;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);

$list=$DB->query("SELECT * FROM pay_settle WHERE pid={$pid} order by id desc limit $offset,$pagesize")->fetchAll();
foreach($list as $res){
	echo '<tr><td>'.$res['id'].'</td><td>'.$res['note'].'</td><td>'.$res['account'].'</td><td>￥ <b>'.$res['money'].'</b></td><td>￥ <b>'.$res['fee'].'</b></td><td>'.$res['time'].'</td><td>'.($res['status']==1?'<font color=green>已完成</font>':'<font color=red>未完成</font>').'</td></tr>';
}
?>
                                </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="panel-footer text-right">
                            <a href="./settle.php" class="btn btn-default btn-sm">查看更多</a>
                        </div>
                    </div>
                </div>
            </div>
        <script type="text/javascript">
        </script>
<?php include 'foot.php';?>