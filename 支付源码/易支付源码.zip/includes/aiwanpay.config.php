<?php
/*爱玩支付配置*/
$pay_config=array(
	'pid' => '17207', //商户ID
	'key' => 'bb2bdfdb71fb21c5704ae59fd005232b', //商户密钥
);
?>