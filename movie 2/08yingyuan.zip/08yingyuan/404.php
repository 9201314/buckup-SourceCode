<?php get_header(); ?>

<section class="container">
	<?php _the_404() ?>
</section>

<?php get_footer(); ?>