<?php _the_focusbox( '', get_the_title(), get_the_excerpt() ); ?>
<style>
#video{width:100%;height:587px;border:none;}
._list{
	margin: 10px 0;
    padding: 0;
}
._list li{
float: left;
list-style: none;
margin: 0 10px;
}
@media only screen and (max-width:500px){
#video{width:100%;height:240px;}
}
.lipbtn {
    background: #fff;
    padding: 5px 8px;
    font-size: 10px;
    border-radius: 10px;
    margin-bottom: 8px;
    border: 1px solid #FF7562;
    clear: both;
    display: inline-block;
    color: #FF7562;
}
</style>
<section class="container">

	<?php while (have_posts()) : the_post(); ?>
 
		<?php

echo '<ul class="_list">';
echo '<span style="float:left;"><span class="txt">选择播放源：</span>&gt;</span>';
echo get_post_meta($post->ID, "yuan_value", true);
echo '</ul>';
	?>
	<div style="clear: both;"></div>
	

	
	
	<iframe id="video" src="/jiazai.html" style="width:100%;border:none;"></iframe>
	<a style="display:none" id="videourlgo" href=""></a>
	<div style="clear: both;"></div>

			

<h2 class="single-strong">简介</h2>		<div class="jianjie">
		<p class="item-desc"><?php the_content(); ?></p>
		</div>
	<?php endwhile; ?>
    
    <?php get_template_part( 'content', 'module-share' ); ?> 
	<h2 class="single-strong">剧情评论</h2><br/>
    <?php comments_template('', true); ?>

	
	
	
	<script type="text/javascript">
	
	function xldata(urls){
	var videourls = document.getElementById('video');
	var xlqieh = document.getElementById('videourlgo');
	videourls.src = urls+xlqieh.href;
	};
	var al = $('._list a');
	al.attr('class','am-btn am-btn-default lipbtn');
	var ji= new Array();
	var btnji= new Array();
	for(var g=0;g<al.length;g++){
		ji.push(al[g].href);
		btnji.push(al[g].id);
		al[g].href = 'javascript:void(0)';
		al[g].target = '_self';
		al.eq(g).attr('onclick','bofang(\''+ji[g]+'\',\''+btnji[g]+'\')');
	};
	document.getElementById('video').src=ji[0];
	function bofang(mp4url){
	document.getElementById('videourlgo').href=mp4url;
	document.getElementById('video').src=mp4url;
	};
</script>


</section>